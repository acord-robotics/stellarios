# Variables
# variableName = value

# Example Variable (int/Integer)
totalScore = 75 #sets the value of "totalScore" to "75"
print(totalScore) #prints the value of "totalScore" (in this case 75) to the console

# Variables can be changed at any time
# Finished "What is a variable and how to define one?" from Udemy