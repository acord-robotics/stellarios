# Data Types in Python

#Classified into 5 categories

#- Numbers
#- Strings
#- Lists
#- Tuples
#- Dictionaries

