# Data Types in Python

Classified into 5 categories

* Numbers
* Strings
* Lists
* Tuples
* Dictionaries

[![forthebadge made-with-python](http://ForTheBadge.com/images/badges/made-with-python.svg)](https://www.python.org/)

