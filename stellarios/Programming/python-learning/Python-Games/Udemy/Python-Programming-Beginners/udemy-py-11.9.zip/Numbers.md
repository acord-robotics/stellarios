# Numbers

* Arithmetic values used for mathematical purposes

2 types of number variables (currently learnt):

```python
myinteger = 20
myfloatingpointnumber = 20.1
```



