# Readme - Udemy  - Programming with Python

This set of notes is from the Udemy "[Programming with Python: Hands-On Introduction for Beginners](https://www.udemy.com/course/python-programming-beginners/)" Course. This repository is 

[![forthebadge made-with-python](http://ForTheBadge.com/images/badges/made-with-python.svg)](https://www.python.org/)

