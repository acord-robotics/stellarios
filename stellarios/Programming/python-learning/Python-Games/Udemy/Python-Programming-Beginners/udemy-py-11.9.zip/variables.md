# What is a variable?
* A variable is a reserved memory location that is used to store values and can be referenced
* Assign values to a variable

# Examples of variables
## Contacts
* Enter contact name "John"
* Look up "John" 
* Like databases