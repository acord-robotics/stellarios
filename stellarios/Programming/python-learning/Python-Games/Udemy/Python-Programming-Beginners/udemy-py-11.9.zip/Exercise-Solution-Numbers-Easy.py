# Assign an integer value 25 to the variable age
age = 25
print(age)

# Output => 25
