# Rules for Defining Variables

a1 = "correct name"
print(a1) #this would print a variable, the variable can be set as it follows the rule listed above

_1 = "correct name" #This is also a correct name for a variable

#1n = "incorrect variable name" #This creates an error
