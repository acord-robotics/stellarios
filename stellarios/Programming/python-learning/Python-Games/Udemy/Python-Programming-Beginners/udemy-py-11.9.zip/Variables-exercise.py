# Easy - Declare a variable without breaking any of the rules
easyvariable = "norulesbroken" # This is a string variable

# I have run this program in the terminal, no errors have been found

# Medium
#break = 50 
# The name of this variable (integer) is a keyword that is used in Python

# Hard
#phone$number = 12345 - Changes to
phonenumber = 12345
#123Name = "Benny" - Changes to
Name123 = Benny