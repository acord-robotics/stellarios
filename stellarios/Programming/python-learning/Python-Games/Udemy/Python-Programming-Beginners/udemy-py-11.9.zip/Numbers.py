myinteger = 20
myfloatingpointnumber = 20.1