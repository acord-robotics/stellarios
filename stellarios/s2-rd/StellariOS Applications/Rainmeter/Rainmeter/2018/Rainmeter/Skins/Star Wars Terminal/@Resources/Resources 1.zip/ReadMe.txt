Star Wars Terminal
Rainmeter Skin
Created by Farficugar

=====================================================================
                             1.1 Changes
=====================================================================

 -Music: Changes picture to be more accurate to movie
 -BB-8 & Death Star Graphic: Replace pictures with better models
 -Star Destroyer: New Graphic
 -Variables: Corrected to work on other computers


======================================================================
                            Note From Author
======================================================================

This is my first Rainmeter skin I have ever made.  I have tried to 
test it and make sure it works on different computers.  If you have
any suggestions or issues, feel free to e-mail me at 
Farficugar@gmail.com with the subject of Star Wars Terminal Skin.  I 
did end up using some pieces from other skins I found online.
I have made sure to give credit to those person below.  Please take
a look at them and their Rainmeter Skin creations.  If you think that 
I used something of yours, please let me know and if so, I will add 
your name to credits. I hope you enjoy the Rainmeter skin.

======================================================================
                        Special Thanks and Credit
======================================================================

Name=99villages
Site=https://99villages.deviantart.com/art/Neon-Space-Rainmeter-2-4-29-09-2017-442236472

Name=JSmorley
Site=https://jsmorley.deviantart.com/

Name=TheSepp
Site=https://thesepp.deviantart.com/


======================================================================
                              Quick Fixes
======================================================================

1. If the Server Check is not working, try putting the paping.exe 
   located in the "@Resources/addons" fold into your 
   "Windows/System32" folder.  Then edit the Server Check and change
   the "PathToPaPing" variable to be "PaPing.exe" instead of 
   "#@#Addons/PaPing.exe".
   
2. If the Frame is not fitting your screen, simply Left Click it and
   it should refresh and fit to the screen.
   
=====================================================================
                               Creator
=====================================================================

                       Star Wars Terminal Ver 1.0
                        (Star Wars Themed Skin)
                          Farficugar@gmail.com
                            Creative Commons 
                    Attribution-Non-Commercial-Share 
                                Alike 3.0
