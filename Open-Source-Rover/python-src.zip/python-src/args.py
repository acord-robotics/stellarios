#! /usr/bin/env python

def main() :
	num = raw_input( 'Please Enter A Number: ' )
	if num.isdigit() :
		print( 'Thanks For Entering ' + num )
		print( num + ' Squared = ' + square( num ) )
		print( num + ' Cubed = ' + cube( num ) ) 
	else :
		print( 'Invalid Entry!' )
		main()

def square( num ) :
	num = int( num )
	return str( num * num )

def cube( num ) :
	num = int( num )
	return str( num * num * num )

main()
