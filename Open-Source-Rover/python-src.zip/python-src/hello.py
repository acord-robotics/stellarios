#! /usr/bin/env python

user = raw_input('I am Raspberry Pi. What is your name?')
print('Welcome ' + user  + '\nHave a nice day!')
