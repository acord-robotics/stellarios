#! /usr/bin/env python

from Tkinter import *

window = Tk()
window.title( 'Relief Example' )

btn_1 = Button( text='Flat', relief=FLAT )

btn_2 = Button( text='Raised' , relief=RAISED )

btn_3 = Button( text='Sunken', relief=SUNKEN )

btn_4 = Button( text='Groove', relief=GROOVE )

btn_5 = Button( text='Ridge', relief=RIDGE )

btn_1.pack(side=TOP, pady=5)
btn_2.pack(side=TOP, pady=5)
btn_3.pack(side=TOP, pady=5)
btn_4.pack(side=TOP, padx=5, pady=5)
btn_5.pack(side=TOP, padx=5, pady=5)

window.mainloop()
