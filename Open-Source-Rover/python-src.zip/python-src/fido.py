#! /usr/bin/env python

from dog import *

pet = raw_input( 'Enter A Pet Name: ' )

bark( pet ) ; lick( pet ) ; nap( pet )
