#! /usr/bin/env python

quarter = ['January', 'February', 'March']
print('First Month: ' +  quarter[0] )
print('Second Month: ' +  quarter[1] )
print('Third Month: ' +  quarter[2] )

coords=[['1','2','3'],['4','5','6']]
print('Top Left 0,0: ' + coords[0][0] ) 
print('Bottom Right 1,2: ' + coords[1][2] ) 

print('First letter in second month: ' + quarter[1][0] )
