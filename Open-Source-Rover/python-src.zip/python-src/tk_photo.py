#! /usr/bin/env python

from Tkinter import *

window=Tk()
window.title( 'Image  Example' )

logo=PhotoImage(file= 'raspi_logo.gif' )

label=Label(window, image=logo, bg='yellow' )

small_logo = PhotoImage.subsample( logo, x=2, y=2 )

btn = Button( window, image=small_logo )

txt = Text( window, width=30, height=9 )
txt.insert( '1.1', 'Raspberry Pi' )
txt.image_create( '1.0', image=small_logo )

can = \
Canvas( window, width=120, height=120, bg='cyan' )
can.create_image( (60,60) , image=small_logo )
can.create_line( 0,0, 120, 120, width=30, fill='yellow' )

label.pack(side=TOP)
btn.pack(side=LEFT, padx=10 )
txt.pack(side=LEFT)
can.pack(side=LEFT, padx=10 )

window.mainloop()
