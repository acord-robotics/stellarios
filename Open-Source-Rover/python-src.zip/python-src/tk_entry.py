#! /usr/bin/env python

from Tkinter import *
import tkMessageBox as box

window=Tk()
window.title( 'Entry Example' )

def dialog():
	box.showinfo( 'Greetings', 'Welcome ' + entry.get() )

frame= Frame(window)

entry=Entry(frame)

btn=Button(frame, text='Enter Name', command=dialog )

btn.pack(side=RIGHT, padx=5)
entry.pack(side=LEFT)

frame.pack(padx=20, pady=20)

window.mainloop()
