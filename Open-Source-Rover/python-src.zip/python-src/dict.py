#! /usr/bin/env python

dict = { 'name':'Mike', 'topic':'Python', 'system':'RasPi' }
print('Dictionary: ' + str( dict ) )

print('Topic: ' + dict['topic'] )

print('Keys: ' + str( dict.keys() ) )

del dict['name']
dict['user'] = 'Anne'
print('Dictionary: ' + str( dict ) ) 

print('Is There A \'name\' Key?: '+ str( 'name' in dict ) ) 
