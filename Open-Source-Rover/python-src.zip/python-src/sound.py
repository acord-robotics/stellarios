#! /usr/bin/env python
import pygame, sys
from pygame.locals import *

pygame.init()
ZONE = pygame.display.set_mode((400,300))
pygame.display.set_caption( 'Game Zone' )

RED = (255, 0, 0) ; YELLOW = (255, 255, 0); BLUE = (0,0,255)

ZONE.fill(BLUE)

FONT = pygame.font.Font( 'freesansbold.ttf', 32)
PLAY_BTN = FONT.render( 'Play', True, RED, YELLOW )

OFFSET = 20

ZONE.blit(PLAY_BTN, (OFFSET, OFFSET) ) 

PLAY_RECT = PLAY_BTN.get_rect()
BTN_L = PLAY_RECT.left + OFFSET
BTN_R = PLAY_RECT.right + OFFSET
BTN_TOP = PLAY_RECT.top + OFFSET
BTN_BTM = PLAY_RECT.bottom + OFFSET

SOUND = pygame.mixer.Sound( 'drum_loop.wav' )

while True :
	for event in pygame.event.get() :
		if event.type == QUIT :
			pygame.quit()
			sys.exit()
		if event.type == MOUSEBUTTONDOWN :
			mouseX, mouseY = pygame.mouse.get_pos()
			if mouseX >= BTN_L and mouseX <= BTN_R and \
			 mouseY >= BTN_TOP and mouseY <= BTN_BTM :
				SOUND.play()
		 
		if event.type == MOUSEBUTTONUP :
			mouseX, mouseY = pygame.mouse.get_pos()
			if mouseX >= BTN_L and mouseX <= BTN_R and \
			 mouseY >= BTN_TOP and mouseY <= BTN_BTM :
				SOUND.stop()
 		 
	pygame.display.update()
