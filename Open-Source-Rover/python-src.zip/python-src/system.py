#! /usr/bin/env python

import sys , keyword

print( '\nPython Version: ' + sys.version )

print( '\nPython Interpreter Location: ' + sys.executable )

print( '\nPython Module Search Path: ' )

for dir in sys.path :
	print( dir )

print( '\nPython Keywords: ' )

for word in keyword.kwlist :
	print( word )
