import RPi.GPIO as GPIO 
from time import sleep
import atexit

GPIO.setmode(GPIO.BOARD)
GPIO.setup( 13, GPIO.OUT )
GPIO.setup( 11, GPIO.OUT )
GPIO.setup( 7, GPIO.OUT )
GPIO.setup( 5, GPIO.IN )
GPIO.setup( 3, GPIO.IN )

def cleanup():
	print( 'Goodbye.' )
	GPIO.cleanup()

atexit.register(cleanup)

run_state = False

def action() :
	if run_state:
		GPIO.output( 7,True);sleep(0.2);GPIO.output( 7,False)
		GPIO.output(11,True);sleep(0.2);GPIO.output(11,False)
		GPIO.output(13,True);sleep(0.2);GPIO.output(13,False)
	else :
		GPIO.output( 7, False )
		GPIO.output(11, False )
		GPIO.output(13, False )

print( 'Push Buttons To Start/Stop LED Sequence' )
print( 'Press Ctrl+C To Exit' )

try :
	while True :
	
		if ( GPIO.input(3) and GPIO.input(5) ) : action()
		elif GPIO.input(5) : 
			run_state = True ;  sleep(0.2)
			print( 'Sequence Running...' )
		elif GPIO.input(3) : 
			run_state = False ; sleep( 0.2 )
			print( 'Sequence Halted.' )

except KeyboardInterrupt :
	
	print('\nScript Exited.' )
