#! /usr/bin/env python

import math, random

print( 'Rounded Up 9.5 : ' + str( math.ceil( 9.5 ) ) ) 
print( 'Rounded Down 9.5 : ' + str( math.floor( 9.5 ) ) )

num = 4
print( str( num ) + ' Squared: ' + str( math.pow( num, 2 ) ) )	
print( str( num ) + ' Square Root: ' + str( math.sqrt( num ) ) )

nums = random.sample( range(1, 59) , 6 )

print( 'Your Lucky Lotto Numbers: ' + str( nums ) )
