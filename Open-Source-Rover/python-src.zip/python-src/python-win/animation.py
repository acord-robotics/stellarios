#! /usr/bin/env python
import pygame, sys
from pygame.locals import *

pygame.init()

ZONE = pygame.display.set_mode((400,300))
pygame.display.set_caption('Game Zone')

RED = (255,0,0)
clock = pygame.time.Clock()

counter = 0
sprites = []

sheet = pygame.image.load('spritesheet.gif').convert_alpha()
width = sheet.get_width()

for i in range( int( width / 128 ) ) :
	sprites.append( sheet.subsurface( i*128, 0, 128, 128))

while True :
	for event in pygame.event.get() :
		if event.type == QUIT :
			pygame.quit()
			sys.exit()
	ZONE.fill(RED)
	ZONE.blit(sprites[counter],(10,10))
	counter = (counter+1) % 8
	clock.tick(16)

	pygame.display.update()
