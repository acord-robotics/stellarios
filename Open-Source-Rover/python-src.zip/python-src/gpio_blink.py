import RPi.GPIO as GPIO
from time import sleep

GPIO.setmode(GPIO.BOARD) ; GPIO.setup( 7, GPIO.OUT)

i = 1
while i < 4 :
	print( 'Cycle: ' + str(i) )
	print '\tSet Output True - LED ON'
	GPIO.output( 7, True) ; sleep(1)
	print( '\tSet Output False - LED OFF' )
	GPIO.output( 7, False) ; sleep(1)
	i += 1
GPIO.cleanup()
