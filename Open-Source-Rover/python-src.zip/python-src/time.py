#! /usr/bin/env python

from  datetime import *

today = datetime.today()

print( 'Today Is: ' + str( today ) )

for attr in \
[ 'year', 'month', 'day', 'hour', 'minute', 'second', 'microsecond' ] :
	print( attr + ':\t' + str( getattr( today, attr) )  )

print( 'Time: ' + str( today.hour ) +':'+ str( today.minute ) ) 

day = today.strftime('%A')
month = today.strftime('%B') 

print( 'Date: ' + day +', '+ month +' '+ str( today.day )  )
