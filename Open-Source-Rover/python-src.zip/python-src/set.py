#! /usr/bin/env python

bag = { 'Red', 'Green', 'Blue' }
print('Set: ' + str( bag ) )

bag.add('Yellow')
print('Enlarged Set: ' + str( bag ) )

print('Is Green In Set?: ' + str('Green' in bag) )

frozenbag = { 'Red', 'Purple', 'Yellow' }
print('Frozen Set: ' + str( frozenbag) )

print('Common To Both Sets: ' + str( bag.intersection(frozenbag) ) )
