#! /usr/bin/env python

from Tkinter import *

window = Tk()
window.title( 'Attribute Example' )

lbl_1 = Label( window, text='A', anchor=N, width=8, \
height=5, bg='black', fg='white', cursor='circle' )

lbl_2 = Label( window, text='B', anchor=S, width=8, \
height=5, bg='red', fg='white', cursor='pirate' )

lbl_3 = Label( window, text='C', anchor=E, width=8, \
height=5, bg='green', cursor='heart' )

lbl_4 = Label( window, text='D', anchor=NE, width=8, \
height=5, bg='yellow', fg='#FF0000', cursor='watch' )

lbl_5 = Label( window, text='E', anchor=SW, width=8, \
height=5, bg='cyan', cursor='spider' )

lbl_1.pack(side=LEFT, padx=5, pady=5)
lbl_2.pack(side=LEFT, padx=5)
lbl_3.pack(side=LEFT, padx=5)
lbl_4.pack(side=LEFT, padx=5)
lbl_5.pack(side=LEFT, padx=5)

window.mainloop()
