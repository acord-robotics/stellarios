#! /usr/bin/env python

zoo = ['Kangaroo', 'Leopard', 'Moose']

seq = ( 100 , 'Bread', zoo )
print('Sequence: ' + str( seq ) )

num, txt, list = seq
print('Item 1: ' + str( num ) )
print('Item 2: ' + txt )
print('Item 3: ' + str( list ) )

seq[2][1] = 'Llama'
print( 'Modified: ' + str( seq ) )
