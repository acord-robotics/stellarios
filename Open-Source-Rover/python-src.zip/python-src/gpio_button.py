import RPi.GPIO as GPIO
from time import sleep

GPIO.setmode(GPIO.BOARD)
GPIO.setup( 7, GPIO.OUT)
GPIO.setup(5, GPIO.IN )

i = 1

while i < 4 :

	if GPIO.input( 5 )  :
		GPIO.output( 7, False )	
	else :
		GPIO.output( 7, True )
		print( 'Button Pushed: ' + str( i ) )
		print( '\t7 Output True - RED ON' )
		sleep(1)
		i += 1

GPIO.cleanup()
