import RPi.GPIO as GPIO
from time import sleep

GPIO.setmode(GPIO.BOARD)

GPIO.setup( 7, GPIO.OUT)
GPIO.setup(11, GPIO.OUT)
GPIO.setup(13, GPIO.OUT)

i = 1
while i < 4 :

	print( 'Cycle: ' + str( i ) )
	
	GPIO.output(7, True)
	print( '\t7 Output True - RED ON' ) ; sleep(1)
	GPIO.output(7, False)

	GPIO.output(11, True) ; print( '\t11 Output True - YELLOW ON' )
	sleep(1)
	GPIO.output(11, False)

	GPIO.output(13, True) ; print( '\t13 Output True - GREEN ON' )
	sleep(1)
	GPIO.output(13, False)

	i += 1

GPIO.cleanup()
