#! /usr/bin/env python
import pygame, sys
from pygame.locals import *

pygame.init()
ZONE = pygame.display.set_mode((400,300))
pygame.display.set_caption('Game Zone')

RED = 	(255, 0, 0) ; YELLOW =	(255, 255, 0); BLUE = 	(0, 0, 255)

ZONE.fill(BLUE)

LOGO = pygame.image.load( 'raspi_logo.gif' )

ZONE.blit( LOGO, (10, 10) )

FONT = pygame.font.Font( 'freesansbold.ttf' , 32)
TEXT = FONT.render( 'Python Gaming', True, RED, YELLOW )

ZONE.blit(TEXT, (100, 150) ) 

while True :
	for event in pygame.event.get() :
		if event.type == QUIT :
			pygame.quit()
			sys.exit()
	pygame.display.update()
