#! /usr/bin/env python
import pygame, sys
from pygame.locals import *

pygame.init()

ZONE = pygame.display.set_mode((400,300))

while True :
	for event in pygame.event.get() :
		if event.type == QUIT :
			pygame.quit()
			sys.exit()
	pygame.display.update()
