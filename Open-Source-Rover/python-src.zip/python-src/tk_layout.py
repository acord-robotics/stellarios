#! /usr/bin/env python

from Tkinter import *

window = Tk()
window.title( 'Layout Example')

lbl_red = Label( window, width= 12, height = 5, bg = 'red' )
lbl_grn = Label( window, width= 12, height = 5, bg = 'green' )
lbl_blu = Label( window, width= 12, height = 5, bg = 'blue' )
lbl_yel = Label( window, width= 12, height = 5, bg = 'yellow' )

#lbl_red.pack(side=TOP)
#lbl_grn.pack(side=BOTTOM) # fill=X
#lbl_blu.pack(side=LEFT)
#lbl_yel.pack(side=RIGHT)

lbl_red.grid( row=1, column=1 )
lbl_grn.grid( row=2, column=2 )
lbl_blu.grid( row=3, column=3 )
lbl_yel.grid( row=1, column=4 ) 

#lbl_red.place( x=10, y=10 ) 
#lbl_grn.place( x=36, y=45 )
#lbl_blu.place( x=63, y=80 )
#lbl_yel.place( x=90, y=115 )

window.mainloop()
