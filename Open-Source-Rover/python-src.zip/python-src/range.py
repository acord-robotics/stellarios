#! /usr/bin/env python

for i in range( 1, 20, 4 ) :
	print( 'Step: ' + str( i ) )
print( '*' * 20 )

langs = [ 'Python', 'Java', 'SQL', 'HTML', 'PHP' ]
for i in range( len( langs ) ) :
	print( 'Language: ' + langs[i] )
print( '*' * 20 )

for i in enumerate( langs ) :
	print( 'Enumerated: ' + str( i )  ) 
print( '*' *  20 )

dict = { 'name':'Mike' , 'topic':'Python', 'system':'RasPi' }
for i, j in dict.items() :
	print( 'Pair: ' + i + ':' + j )
print( '*' * 20 )

chars = [ 'A', 'B', 'C', 'D', 'E' ]
for i, j in zip( chars, langs ) :
	print( 'Both: ' + i + ':' + j )
