#! /usr/bin/env python

user = 'Anne'
for char in user :
	 print('String Character: ' + char)
print('*' * 20)

quarter = ['January', 'February', 'March' ]
for month in quarter :
	print('List Element: ' +  month)
print('*' * 20)

seq = (100, 'Bread', quarter )
for item in seq :
	print('Tuple Item: ' + str( item ) )
print('*' * 20)

bag = { 'Red', 'Green', 'Blue' }
for color in bag :
	print('Set Member: ' + color )
print('*' * 20)

dict = { 'name':'Mike' , 'topic':'Python', 'system':'RasPi' }  
for key in dict :
	print('Dictionary Pair: ' + key + ':' +  dict[key] ) 
