#! /usr/bin/env python
import pygame, sys
from pygame.locals import *

pygame.init()

ZONE = pygame.display.set_mode((400,300))
pygame.display.set_caption('Game Zone')


BLUE=(0,0,255)
SAUCER=pygame.image.load('saucer.gif')

x=y=10
mod_x=mod_y=10

clock=pygame.time.Clock()

while True :

	x+=mod_x
	y+=mod_y
	ZONE.fill(BLUE)
	ZONE.blit(SAUCER,(x,y))

	for event in pygame.event.get() :
		if event.type == QUIT :
			pygame.quit()
			sys.exit()

	keys=pygame.key.get_pressed()
	if keys[ pygame.K_RIGHT ] : mod_x = 3
	elif keys[ pygame.K_LEFT ] : mod_x = -3
	elif keys[ pygame.K_UP ] : mod_y = -3
	elif keys[ pygame.K_DOWN ] : mod_y = 3
	else : mod_x = mod_y = 0
	pygame.display.update()

	clock.tick(30)
