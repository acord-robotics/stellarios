#! /usr/bin/env python

try :
	num = int( raw_input( 'Enter A Number: ' ) )
	print( 'Thanks For Entering ' + str( num ) )
except ValueError as description :
	print( 'Oops! Looks Like An Invalid Entry:' )
	print( str( description ) )

