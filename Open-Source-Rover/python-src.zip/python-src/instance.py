#! /usr/bin/env python

from super import Bird

polly = Bird( 'Tweet,tweet!' )

print( 'Polly says: ' + polly.talk() )

