#! /usr/bin/env python

basket = ['Apple', 'Banana', 'Cherry']
crate = ['Eggplant', 'Fig', 'Grape']

print('Basket List: ' + str(basket) )
print('Basket Elements: ' + str( len(basket) ) )

basket.append('Date')
print('Appended: ' + str(basket) )

print('Last Item Removed: ' + basket.pop() )
print('Basket List: ' + str(basket) )

basket.extend(crate)
print('Extended: ' + str(basket) )

del basket[1]
print('Item Removed: ' + str(basket) )

del basket[1:3]
print('Slice Removed: ' + str(basket) )
