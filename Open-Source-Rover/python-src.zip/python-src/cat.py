
def purr( pet = 'A cat' ) :
	print( pet + ' says MEOW!' )

def lick( pet = 'A cat' ) :
	print( pet + ' drinks milk' )

def nap( pet = 'A cat' ) :
	print( pet + ' sleeps by the fire' )
