#! /usr/bin/env python

i = 1

while i < 4  :
	print('Outer Loop Iteration ' + str( i ) )
	i += 1

	j = 1
	while j < 4 :
		print('\tInner Loop Iteration ' + str( j ) )
		j = j+1	
