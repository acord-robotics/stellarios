#! /usr/bin/env python

from Tkinter import *

window = Tk()

window.mainloop()
