from super import Bird

class Dove( Bird ) :

	def __init__( self ) :
		self.sound = 'Coo,coo!\n'

class Chicken( Bird ) :

	def __init__( self ) :
		self.sound = 'Cluck,cluck!'
		self.flight = 'I\'m just a chicken - I can\'t fly!'

	def fly( self ) :
		return self.flight

