
def bark( pet = 'A dog' ) :
	print( pet + ' says WOOF!' )

def lick( pet = 'A dog' ) :
	print( pet + ' drinks water' )

def nap( pet = 'A dog' ) :
	print( pet + ' sleeps in the sun' )
