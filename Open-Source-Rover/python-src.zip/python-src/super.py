class Bird :

	def __init__( self, sound ) :
		self.sound = sound

	def talk( self ) :
		return self.sound

