#! /usr/bin/env python

from dog import bark, lick, nap

bark() ; lick() ; nap()

bark( 'Pooch' ) ; lick( 'Pooch' ) ; nap( 'Pooch' )
