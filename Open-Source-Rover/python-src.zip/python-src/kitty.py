#! /usr/bin/env python

import cat

cat.purr()
cat.lick()
cat.nap()

name = 'Kitty'

cat.purr( name )
cat.lick( name )
cat.nap( name )
