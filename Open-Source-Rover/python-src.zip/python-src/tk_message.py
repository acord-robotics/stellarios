#! /usr/bin/env python

from Tkinter import *
import tkMessageBox as box

window=Tk()
window.title( 'Message Box Example' )

def dialog():

	var = box.askyesno( 'Message Box', 'Proceed?' )

	if var == 1 :
		box.showinfo( 'Box', 'Proceeding...' )
	else :
		box.showwarning( 'Box', 'Cancelling...' )

btn=Button(window, text='Click', command=dialog )

btn.pack(padx=100, pady=50)

window.mainloop()
