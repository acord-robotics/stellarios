#! /usr/bin/env python
import pygame, sys
from pygame.locals import *

pygame.init()
ZONE = pygame.display.set_mode((400,300))
pygame.display.set_caption( 'Game Zone' )

RED = 	(255, 0, 0)
GREEN =	(0, 255, 0)
BLUE = 	(0, 0, 255)
YELLOW = (255, 255, 0)
WHITE = (255, 255, 255)
FUCHSIA = (255, 0, 255)

ZONE.fill(BLUE)

pygame.draw.rect(ZONE, RED, (25, 25, 100, 100) )
pygame.draw.circle(ZONE, GREEN, (200, 75), 50 )
pygame.draw.polygon(ZONE, YELLOW, \
( (275, 125), (325, 25), (375, 125) ) )
pygame.draw.line(ZONE, WHITE, (25, 150), (375, 150), 10 )
pygame.draw.ellipse(ZONE, FUCHSIA, (25, 180, 350, 100) ) 

while True :
	for event in pygame.event.get() :
		if event.type == QUIT :
			pygame.quit()
			sys.exit()
	pygame.display.update()
