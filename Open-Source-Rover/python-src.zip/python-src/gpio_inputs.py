import RPi.GPIO as GPIO 
from time import sleep

GPIO.setmode(GPIO.BOARD)

GPIO.setup( 13, GPIO.OUT )
GPIO.setup( 11, GPIO.OUT )
GPIO.setup( 7, GPIO.OUT )
GPIO.setup( 5, GPIO.IN )
GPIO.setup( 3, GPIO.IN )

red_state = False
grn_state = False

i = 0
while i < 8 :
	if ( GPIO.input(3) and GPIO.input(5) ) :
		GPIO.output( 7, red_state )
		GPIO.output(11, False )
		GPIO.output(13, grn_state )
	elif GPIO.input(5) :
		red_state = not red_state
		i += 1 ; sleep(0.2)
		if red_state : print(str(i) + ': RED ON')
		else : print( str(i) + ': RED OFF' )
	elif GPIO.input(3) : 
		grn_state = not grn_state
		i += 1; sleep(0.2)
		if grn_state : print( str(i) + ': GREEN ON' )
		else : print( str(i) + ': GREEN OFF' )
GPIO.cleanup()
