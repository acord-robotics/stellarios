#! /usr/bin/env python

num = input('Please Enter A Number: ')

def thank() :
	print('Thanks For Entering ' + str( num ) )

def square() :
	result =  num * num
	return str( num ) + ' Squared = ' + str( result )

def cube() :
	global result
	result = num * num * num
	return str( num ) + ' Cubed = ' + str( result )

thank()
print( square() )
print( cube() )
