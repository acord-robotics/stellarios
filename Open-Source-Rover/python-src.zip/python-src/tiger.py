#! /usr/bin/env python

import cat

pet = raw_input( 'Enter A Pet Name: ' )

cat.purr( pet ) ; cat.lick( pet ) ; cat.nap( pet )
