#! /usr/bin/env python

snack = '{0} and {1}'.format( 'Burger' , 'Fries' ) 

print( 'Substituted: ' + snack )

print( 'Capitalized: ' + snack.capitalize() )

print( 'Uppercase: ' + snack.upper() )

print( 'Titled: ' + snack.title() )

print( 'Swapped: ' + snack.swapcase( ) )

print( 'Padded: ' + snack.rjust(20) )
