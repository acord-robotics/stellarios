#! /usr/bin/env python

from sub import Dove, Chicken

joey = Dove()

print( 'Joey says: ' + joey.talk() )

babs = Chicken()

print( 'Babs says: ' + babs.talk() )
print( babs.fly() )

