#! /usr/bin/env python

num = input('Please Enter A Number: ')

if num > 5 :
	print('Number Exceeds 5')
elif num < 5 :
	print('Number Is Less Than 5')
else :
	print('Number Is 5')

if num > 7 and num < 9 :
	print('Number Is 8')

if num == 1 or num == 3 :
	print('Number Is 1 Or 3')
